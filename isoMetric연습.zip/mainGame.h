#pragma once
#include "gameNode.h"
#include "aStarTestScene.h"
#include "packmanScene.h"
#include "aStarTestScene.h"

#define TILEWIDTH 64
#define TILEHEIGHT 64

#define TILEX 10
#define TILEY 10


class mainGame : public gameNode
{
private:
	POINT _tile[TILEX * TILEY];
	POINT _isometric[TILEX * TILEY];

	bool _isBlueTile[TILEX * TILEY];

	bool _isTile;

public:
	virtual HRESULT init(void);
	virtual void release(void);
	virtual void update(void);
	virtual void render();

	virtual void checkPickTile();


	mainGame();
	~mainGame();
};

