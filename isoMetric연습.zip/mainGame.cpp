#include "stdafx.h"
#include "mainGame.h"


mainGame::mainGame()
{
}


mainGame::~mainGame()
{
}
////////////////////////////////////
//������ �Ҹ��� ���̺���
////////////////////////////////////

//�ʱ�ȭ ���ִ� �Լ�
HRESULT mainGame::init(void)
{
	gameNode::init(true);

	// SCENEMANAGER->addScene("�ѸǾ�", new packmanScene);
	// SCENEMANAGER->changeScene("�ѸǾ�");

	_isTile = true;

	for (int i = 0; i < TILEY; ++i)
	{
		for (int k = 0; k < TILEX; ++k)
		{
			_tile[i*TILEX + k].x = k * TILEWIDTH;
			_tile[i*TILEX + k].y = i * TILEHEIGHT;
			_isBlueTile[i*TILEX + k] = false;
		}
	}

	for (int i = 0; i < TILEY; ++i)
	{
		for (int k = 0; k < TILEX; ++k)
		{
			_isometric[i*TILEX + k].x = (k - i) * TILEWIDTH;
			_isometric[i*TILEX + k].y = (k + i) * (TILEHEIGHT / 2);
		}
	}

	
	return S_OK;
}

//�޸� �����Լ�
void mainGame::release(void)
{
	gameNode::release();

}

//���� �ϴ� ��
void mainGame::update(void)
{
	gameNode::update();

	
	if (KEYMANAGER->isOnceKeyDown(VK_F1))
	{
		if (_isTile) _isTile = false;
		else _isTile = true;
	}

	if (_isTile && KEYMANAGER->isStayKeyDown(VK_LBUTTON))
	{
		for (int i = 0; i < TILEX * TILEY; i++)
		{
			if (_tile[i].x < _ptMouse.x && _ptMouse.x < _tile[i].x + TILEWIDTH &&
				_tile[i].y < _ptMouse.y && _ptMouse.y < _tile[i].y + TILEHEIGHT)
			{
				_isBlueTile[i] = true;
				break;
			}	
		}
	}
	if (!_isTile && KEYMANAGER->isOnceKeyDown(VK_LBUTTON))
	{
	
		for (int i = 99; i >= 0; --i)
		{
			
			int centerX = _isometric[i].x + WINSIZEX / 2;
			int centerY = _isometric[i].y + (TILEHEIGHT / 2);
			float fTouch = fabs(centerX - _ptMouse.x) / centerX + fabs(centerY - _ptMouse.y) / centerY;
		
			if (fTouch < 1.0f)
			{
				_isBlueTile[i] = true;
			}
		}
		


	}
	
	if (KEYMANAGER->isOnceKeyDown(VK_RBUTTON))
	{
		for (int i = 0; i < 100; ++i)
		{
			_isBlueTile[i] = false;
		}
	}


	// SCENEMANAGER->update();
		
}

//�׷��ִ� ��
void mainGame::render()
{
	//��� ��ȭ�� ������ �ʿ���
	PatBlt(getMemDC(), 0, 0, WINSIZEX, WINSIZEY, WHITENESS);

	HBRUSH hPen, oldPen;

	if (_isTile)
	{
		for (int i = 0; i < 100; i++)
		{
			if (_isBlueTile[i])
			{
				hPen = CreateSolidBrush(RGB(0, 0, 255));
				oldPen = (HBRUSH)SelectObject(getMemDC(), hPen);
				RectangleMake(getMemDC(), _tile[i].x, _tile[i].y, TILEWIDTH, TILEHEIGHT);
				SelectObject(getMemDC(), oldPen);
			}
			else RectangleMake(getMemDC(), _tile[i].x, _tile[i].y, TILEWIDTH, TILEHEIGHT);
		}
	}
	else
	{
		for (int y = 0; y < TILEY - 1; ++y)
		{
			for (int x = 0; x < TILEX - 1; ++x)
			{
				LineMake(getMemDC(), _isometric[y * TILEX + x].x + WINSIZEX/2, _isometric[y * TILEX + x].y,
					_isometric[y * TILEX + x + 1].x + WINSIZEX / 2, _isometric[y * TILEX + x + 1].y);

				LineMake(getMemDC(), _isometric[y * TILEX + x].x + WINSIZEX / 2, _isometric[y * TILEX + x].y,
					_isometric[(y + 1) * TILEX + x].x + WINSIZEX / 2, _isometric[(y + 1) * TILEX + x].y);
			
				
				TCHAR str[100];
				sprintf_s(str, "[%d,%d]", x, y);
				TextOut(getMemDC(), _isometric[y * TILEX + x].x + WINSIZEX / 2 - 10, _isometric[y * TILEX + x].y,
					str, strlen(str));

			}
		}
	}
	


	// SCENEMANAGER->render();

	//����ۿ� �Ű� �׷��� �� �ǵ������� ���
	this->getBackBuffer()->render(getHDC(), 0, 0);

}

void mainGame::checkPickTile()
{
}

